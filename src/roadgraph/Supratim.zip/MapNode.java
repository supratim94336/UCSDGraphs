package roadgraph;

import geography.GeographicPoint;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Supra on 28/12/2016.
 */
public class MapNode {
    /**
     * A MapNode is a vertex on a map (which is nothing but a location having latitude and longitude values)
     * A MapNode have a set of edges to other vertices
     */
    private GeographicPoint location;
    private List<MapEdge> edges;

    /**
     * Constructor to initiate a MapNode
     */
    public MapNode(GeographicPoint location, List<MapEdge> edges){
        this.location=location;
        this.edges = edges;
    }

    /**
     * Corresponding getters and setters
     */
    public GeographicPoint getLocation() {
        return location;
    }

    public void setLocation(GeographicPoint location) {
        this.location = location;
    }

    public List<MapEdge> getEdges() {
        return edges;
    }

    public void setEdges(List<MapEdge> edges) {
        this.edges = edges;
    }
    /**
     * Method to get the neighbors of a node
     */
    public Set<MapNode> getNeighbors(){
        Set<MapNode> neighbors = new HashSet<>();
        for (MapEdge edge : edges) {
            neighbors.add(edge.getOtherNode(this));
        }
        return neighbors;
    }
}
